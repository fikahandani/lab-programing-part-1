#include<stdio.h>

int main(){
	int input;
	printf("input : ");
	scanf("%d",&input);
	if(input%2 == 0){
		printf("%d merupakan bilangan genap\n",input);
	}
	else{
		printf("%d merupakan bilangan ganjil\n",input);
	}
}
