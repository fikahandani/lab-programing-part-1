#include<stdio.h>

int main(){
	int input;
	printf("Jumlah yang akan di fotokopi : ");
	scanf("%d",&input);
	if(input<10){
		printf("Harga foto kopi perlembar Rp.200\n");
	}
	else if(input>=10 && input<50){
		printf("Harga fotokopi perlembar Rp.150\n");
	}
	else if(input>=50 && input<100){
		printf("Harga fotokopi perlembar Rp.125\n");
	}
	else if(input>=100){
		printf("Harga fotokopi perlembar Rp.100\n");
	}
}
