#include<stdio.h>

int main(){
	int a,b,c,d,e;
	float average;
	printf("masukkan bilangan ke-1 : ");
	scanf("%d",&a);
	printf("masukkan bilangan ke-2 : ");
	scanf("%d",&b);
	printf("masukkan bilangan ke-3 : ");
	scanf("%d",&c);
	printf("masukkan bilangan ke-4 : ");
	scanf("%d",&d);
	printf("masukkan bilangan ke-5 : ");
	scanf("%d",&e);
	average=(a+b+c+d+e)/5;
	printf("rata-rata bilangan tersebut adalah %f",average);
}
