#include<stdio.h>

int main(){
	int a;
	int b;
	
	printf("Perbandingan dua buah bilangan integer\n");
	printf("masukkan angka pertama : ");
	scanf("%d",&a);
	printf("masukkan angka kedua : ");
	scanf("%d",&b);
	
	if(a==b){
		printf("%d sama dengan %d\n",a,b);
	}
	else if(a>b){
		printf("%d lebih besar dari %d\n",a,b);
	}
	else{
		printf("%d lebih kecil dari %d\n",a,b);
	}
	
}
