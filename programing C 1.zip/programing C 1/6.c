#include<stdio.h>

int main(){
	int input;
	printf("masukkan sebuah bilangan : ");
	scanf("%d",&input);
	if(input%5 == 0){
		printf("%d merupakan bilangan kelipatan 5",input);
	}
	else{
		printf("%d merupakan bilangan bukan kelipatan 5",input);
	}
}
