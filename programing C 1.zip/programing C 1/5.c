#include<stdio.h>

int main(){
	int input;
	printf("masukkan nilai : ");
	scanf("%d",&input);
	if(input/10 <= 9 && input/10>0){
		printf("%d adalah bilangan puluhan",input);
	}
	else if(input/10 >9 && input/100<=9){
		printf("%d adalah bilangan ratusan",input);
	}
	else{
		printf("%d adalah bilangan satuan atau lebih dari ratusan",input);
	}
}
