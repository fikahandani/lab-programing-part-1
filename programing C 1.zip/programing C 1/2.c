#include<stdio.h>

int main(){
	int a,b;
	int sum;
	printf("masukkan angka pertama : ");
	scanf("%d",&a);
	printf("masukkan angka kedua : ");
	scanf("%d",&b);
	sum=a+b;
	printf("hasil penjumlahan dari %d dan %d adalah %d\n",a,b,sum);
}
